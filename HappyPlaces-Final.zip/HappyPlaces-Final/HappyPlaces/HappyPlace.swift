//
//  HappyPlace.swift
//  HappyPlaces
//
//  Created by Denis Panjuta on 12/08/15.
//  Copyright © 2015 panjutorials. All rights reserved.
//

import Foundation

class HappyPlace {
    
    var name: String
    let lat: Double
    let long: Double
    
    init(name: String, lat: Double, long: Double)
    {
        self.name = name
        self.lat = lat
        self.long = long
    }
    
    
}