//
//  NewLocationDelegate.swift
//  HappyPlaces
//
//  Created by Denis Panjuta on 12/08/15.
//  Copyright © 2015 panjutorials. All rights reserved.
//

protocol NewLocationDelegate{
    
    func newLocationAdded(name: String, lat: Double, long: Double)
    
}
