//
//  DetailViewController.swift
//  HappyPlaces
//
//  Created by Denis Panjuta on 12/08/15.
//  Copyright © 2015 panjutorials. All rights reserved.
//

import UIKit
import MapKit

class DetailViewController: UIViewController, CLLocationManagerDelegate, UISearchBarDelegate {
    
    var aPlace: HappyPlace?
    
    var locationMgr: CLLocationManager!
    
    var searchAnnotation: MKAnnotation!
    
    var newLocationDelegate: NewLocationDelegate?
    
    var _masterTableViewController: NewLocationDelegate?{
        get {
            let navController = self.splitViewController?.viewControllers[0] as! UINavigationController
            let master = navController.viewControllers[0] as! MasterTableViewController
            return master
            
        }
    }
    
    func locationManager(manager: CLLocationManager, didUpdateToLocation newLocation: CLLocation, fromLocation oldLocation: CLLocation)
    {
        locationMgr.stopUpdatingLocation()
        
        let coordinate = newLocation.coordinate
        let pointAnnotation = MKPointAnnotation()
        pointAnnotation.coordinate = CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude)
        
        let pinAnnotation = MKPinAnnotationView(annotation: pointAnnotation, reuseIdentifier: nil)
        
        self.mapOutlet.centerCoordinate = pointAnnotation.coordinate
        self.mapOutlet.addAnnotation(pinAnnotation.annotation!)
        
    }
    
    
    
    @IBAction func myLocationAction(sender: AnyObject) {
        
        locationMgr.requestWhenInUseAuthorization()
        locationMgr.startUpdatingLocation()
        locationMgr.delegate = self
    }
    
    
    
    

    @IBAction func searchTapped(sender: AnyObject) {
        let search = UISearchController(searchResultsController: nil)
        search.hidesNavigationBarDuringPresentation = false
        search.searchBar.delegate = self
        presentViewController(search, animated: true, completion: nil)
        
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        dismissViewControllerAnimated(true, completion: nil)
        
        if self.mapOutlet.annotations.count > 0 {
            searchAnnotation = self.mapOutlet.annotations[0] as MKAnnotation
            self.mapOutlet.removeAnnotation(searchAnnotation)
        }
        
        
        let localSearchRequest = MKLocalSearchRequest()
        localSearchRequest.naturalLanguageQuery = searchBar.text
        
        let localSearch = MKLocalSearch(request: localSearchRequest)
        localSearch.startWithCompletionHandler({
            (response, error) -> Void in
            
            if response != nil {
                let foundLocation = response?.boundingRegion.center
                
                let poinAnnotation = MKPointAnnotation()
                poinAnnotation.title = searchBar.text
                poinAnnotation.coordinate = CLLocationCoordinate2D(latitude: (foundLocation?.latitude)!, longitude: (foundLocation?.longitude)!)
                
                let pinAnnotation = MKPinAnnotationView(annotation: poinAnnotation, reuseIdentifier: nil)
                
                
                self.mapOutlet.centerCoordinate = poinAnnotation.coordinate
                self.mapOutlet.addAnnotation(pinAnnotation.annotation!)
                
            }
            
            
            
        })
    }
    
    
    @IBOutlet weak var mapOutlet: MKMapView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationMgr = CLLocationManager()
        locationMgr.delegate = self
        locationMgr.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        
        
        newLocationDelegate = _masterTableViewController
        
        if aPlace != nil {
            let lat = aPlace?.lat
            let long = aPlace?.long
            let location = CLLocationCoordinate2DMake(lat!, long!)
            
            let span = MKCoordinateSpanMake(0.05, 0.05)
            
            let region = MKCoordinateRegionMake(location, span)
            
            self.mapOutlet.setRegion(region, animated: true)
            
            let annotation = MKPointAnnotation()
            annotation.title = aPlace?.name
            annotation.coordinate = location
            self.mapOutlet.addAnnotation(annotation)
            
            self.title = aPlace?.name
            
            
        }
        
        let pinGesture = UILongPressGestureRecognizer(target: self, action: "newLocation:")
        pinGesture.minimumPressDuration = 1.5
        self.mapOutlet.addGestureRecognizer(pinGesture)
        
    }
    
    
    func newLocation(gestureRecognizer: UIGestureRecognizer)
    {
        if gestureRecognizer.state == UIGestureRecognizerState.Began
        {
            
            let touched = gestureRecognizer.locationInView(self.mapOutlet)
            
            let touchCoordinates = mapOutlet.convertPoint(touched, toCoordinateFromView: self.mapOutlet)
            
            let location = CLLocation(latitude: touchCoordinates.latitude, longitude: touchCoordinates.longitude)
            
            CLGeocoder().reverseGeocodeLocation(location, completionHandler:
            {
                (placemarks, error) -> Void in
                var title = ""
                if error == nil
                {
                    
                    if let validPlacemark = placemarks?[0]
                    {
                        let placemark = validPlacemark as? CLPlacemark
                        
                        var street = ""
                        var city = ""
                        
                        if placemark!.thoroughfare != nil
                        {
                            street = placemark!.thoroughfare!
                        }
                        
                        if placemark!.subAdministrativeArea != nil
                        {
                            city = placemark!.subAdministrativeArea!
                        }
                        title = "\(street), \(city)"
                    }
                    
                }
                
                let delegate = self.newLocationDelegate!
                delegate.newLocationAdded(title, lat: touchCoordinates.latitude, long: touchCoordinates.longitude)
                
                let annotation = MKPointAnnotation()
                annotation.coordinate = touchCoordinates
                annotation.title = title
                self.mapOutlet.addAnnotation(annotation)
                
            })
            
            
        }
        
        
        
    }
    
    
    
    
    


}
